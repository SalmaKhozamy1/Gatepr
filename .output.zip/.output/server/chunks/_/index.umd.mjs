import * as Vue from 'vue';
import { mergeProps, useSSRContext } from 'vue';
import { ssrRenderAttrs } from 'vue/server-renderer';
import { _ as _export_sfc } from '../build/server.mjs';
import * as flatpickr from 'flatpickr';

const _sfc_main = {};
function _sfc_ssrRender(_ctx, _push, _parent, _attrs) {
  _push(`<svg${ssrRenderAttrs(mergeProps({
    xmlns: "http://www.w3.org/2000/svg",
    width: "24",
    height: "24",
    viewBox: "0 0 24 24",
    fill: "none"
  }, _attrs))}><path d="M18 1.25C18.4142 1.25 18.75 1.58579 18.75 2V2.63574C19.5546 2.86384 20.2339 3.23403 20.7988 3.84473C21.5764 4.68557 21.9223 5.7479 22.0879 7.0791C22.2502 8.3839 22.25 10.0568 22.25 12.1904V12.8096C22.25 14.9432 22.2502 16.6161 22.0879 17.9209C21.9223 19.2521 21.5764 20.3144 20.7988 21.1553C20.0133 22.0045 19.0074 22.3903 17.749 22.5732C16.531 22.7503 14.9744 22.75 13.0107 22.75H10.9893C9.02556 22.75 7.46901 22.7503 6.25098 22.5732C4.99258 22.3903 3.98672 22.0045 3.20117 21.1553C2.42359 20.3144 2.0777 19.2521 1.91211 17.9209C1.74984 16.6161 1.74999 14.9431 1.75 12.8096V12.1904C1.74999 10.0569 1.74984 8.3839 1.91211 7.0791C2.0777 5.7479 2.42359 4.68557 3.20117 3.84473C3.76607 3.23403 4.44535 2.86384 5.25 2.63574V2C5.25 1.58579 5.58579 1.25 6 1.25C6.41421 1.25 6.75 1.58579 6.75 2V2.36523C7.88605 2.24932 9.28407 2.24998 10.9893 2.25H13.0107C14.7159 2.24998 16.114 2.24932 17.25 2.36523V2C17.25 1.58579 17.5858 1.25 18 1.25ZM20.709 8.71582C20.6423 8.73526 20.573 8.75 20.5 8.75H3.5C3.42669 8.75 3.35701 8.73543 3.29004 8.71582C3.25029 9.6796 3.25 10.8341 3.25 12.2432V12.7568C3.25 14.9551 3.25099 16.5339 3.40039 17.7354C3.5478 18.9207 3.82862 19.6241 4.30273 20.1367C4.76922 20.641 5.39716 20.9334 6.4668 21.0889C7.56448 21.2484 9.01178 21.25 11.0498 21.25H12.9502C14.9882 21.25 16.4355 21.2484 17.5332 21.0889C18.6028 20.9334 19.2308 20.641 19.6973 20.1367C20.1714 19.6241 20.4522 18.9207 20.5996 17.7354C20.749 16.5339 20.75 14.9551 20.75 12.7568V12.2432C20.75 10.8341 20.7487 9.67961 20.709 8.71582ZM8.00879 16C8.56107 16 9.00879 16.4477 9.00879 17C9.00879 17.5523 8.56107 18 8.00879 18H8C7.44772 18 7 17.5523 7 17C7 16.4477 7.44772 16 8 16H8.00879ZM12.0049 16C12.557 16.0002 13.0049 16.4478 13.0049 17C13.0049 17.5522 12.557 17.9998 12.0049 18H11.9951C11.443 17.9998 10.9951 17.5522 10.9951 17C10.9951 16.4478 11.443 16.0002 11.9951 16H12.0049ZM8.00879 12C8.56107 12 9.00879 12.4477 9.00879 13C9.00879 13.5523 8.56107 14 8.00879 14H8C7.44772 14 7 13.5523 7 13C7 12.4477 7.44772 12 8 12H8.00879ZM12.0049 12C12.557 12.0002 13.0049 12.4478 13.0049 13C13.0049 13.5522 12.557 13.9998 12.0049 14H11.9951C11.443 13.9998 10.9951 13.5522 10.9951 13C10.9951 12.4478 11.443 12.0002 11.9951 12H12.0049ZM16 12C16.5523 12 17 12.4477 17 13C17 13.5523 16.5523 14 16 14H15.9912C15.4389 14 14.9912 13.5523 14.9912 13C14.9912 12.4477 15.4389 12 15.9912 12H16ZM11.0498 3.75C9.18218 3.75 7.81099 3.75294 6.75 3.87598V4C6.75 4.41421 6.41421 4.75 6 4.75C5.65792 4.75 5.37237 4.52011 5.28223 4.20703C4.87357 4.36922 4.56265 4.58229 4.30273 4.86328C3.82966 5.37481 3.54904 6.07617 3.40137 7.25684C3.43366 7.25259 3.46655 7.25 3.5 7.25H20.5C20.5331 7.25 20.5657 7.25267 20.5977 7.25684C20.45 6.07624 20.1703 5.37479 19.6973 4.86328C19.4372 4.5821 19.1259 4.36926 18.7168 4.20703C18.6266 4.51997 18.342 4.75 18 4.75C17.5858 4.75 17.25 4.41421 17.25 4V3.87598C16.189 3.75294 14.8178 3.75 12.9502 3.75H11.0498Z" fill="currentColor"></path></svg>`);
}
const _sfc_setup = _sfc_main.setup;
_sfc_main.setup = (props, ctx) => {
  const ssrContext = useSSRContext();
  (ssrContext.modules || (ssrContext.modules = /* @__PURE__ */ new Set())).add("components/Icons/calander.vue");
  return _sfc_setup ? _sfc_setup(props, ctx) : void 0;
};
const __nuxt_component_0 = /* @__PURE__ */ Object.assign(_export_sfc(_sfc_main, [["ssrRender", _sfc_ssrRender]]), { __name: "IconsCalander" });

function getDefaultExportFromCjs (x) {
	return x && x.__esModule && Object.prototype.hasOwnProperty.call(x, 'default') ? x['default'] : x;
}

function getDefaultExportFromNamespaceIfNotNamed (n) {
	return n && Object.prototype.hasOwnProperty.call(n, 'default') && Object.keys(n).length === 1 ? n['default'] : n;
}

var index_umd$1 = {exports: {}};

const require$$0 = /*@__PURE__*/getDefaultExportFromNamespaceIfNotNamed(flatpickr);

const require$$1 = /*@__PURE__*/getDefaultExportFromNamespaceIfNotNamed(Vue);

var index_umd = index_umd$1.exports;

(function (module, exports$1) {
	(function webpackUniversalModuleDefinition(root, factory) {
		module.exports = factory(require$$0, require$$1);
	})(index_umd, (__WEBPACK_EXTERNAL_MODULE__144__, __WEBPACK_EXTERNAL_MODULE__594__) => {
	return /******/ (() => { // webpackBootstrap
	/******/ 	var __webpack_modules__ = ({

	/***/ 144:
	/***/ ((module) => {

	module.exports = __WEBPACK_EXTERNAL_MODULE__144__;

	/***/ }),

	/***/ 594:
	/***/ ((module) => {

	module.exports = __WEBPACK_EXTERNAL_MODULE__594__;

	/***/ })

	/******/ 	});
	/************************************************************************/
	/******/ 	// The module cache
	/******/ 	var __webpack_module_cache__ = {};
	/******/ 	
	/******/ 	// The require function
	/******/ 	function __webpack_require__(moduleId) {
	/******/ 		// Check if module is in cache
	/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
	/******/ 		if (cachedModule !== undefined) {
	/******/ 			return cachedModule.exports;
	/******/ 		}
	/******/ 		// Create a new module (and put it into the cache)
	/******/ 		var module = __webpack_module_cache__[moduleId] = {
	/******/ 			// no module.id needed
	/******/ 			// no module.loaded needed
	/******/ 			exports: {}
	/******/ 		};
	/******/ 	
	/******/ 		// Execute the module function
	/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
	/******/ 	
	/******/ 		// Return the exports of the module
	/******/ 		return module.exports;
	/******/ 	}
	/******/ 	
	/************************************************************************/
	/******/ 	/* webpack/runtime/compat get default export */
	/******/ 	(() => {
	/******/ 		// getDefaultExport function for compatibility with non-harmony modules
	/******/ 		__webpack_require__.n = (module) => {
	/******/ 			var getter = module && module.__esModule ?
	/******/ 				() => (module['default']) :
	/******/ 				() => (module);
	/******/ 			__webpack_require__.d(getter, { a: getter });
	/******/ 			return getter;
	/******/ 		};
	/******/ 	})();
	/******/ 	
	/******/ 	/* webpack/runtime/define property getters */
	/******/ 	(() => {
	/******/ 		// define getter functions for harmony exports
	/******/ 		__webpack_require__.d = (exports$1, definition) => {
	/******/ 			for(var key in definition) {
	/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports$1, key)) {
	/******/ 					Object.defineProperty(exports$1, key, { enumerable: true, get: definition[key] });
	/******/ 				}
	/******/ 			}
	/******/ 		};
	/******/ 	})();
	/******/ 	
	/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
	/******/ 	(() => {
	/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop));
	/******/ 	})();
	/******/ 	
	/******/ 	/* webpack/runtime/make namespace object */
	/******/ 	(() => {
	/******/ 		// define __esModule on exports
	/******/ 		__webpack_require__.r = (exports$1) => {
	/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
	/******/ 				Object.defineProperty(exports$1, Symbol.toStringTag, { value: 'Module' });
	/******/ 			}
	/******/ 			Object.defineProperty(exports$1, '__esModule', { value: true });
	/******/ 		};
	/******/ 	})();
	/******/ 	
	/************************************************************************/
	var __webpack_exports__ = {};
	// ESM COMPAT FLAG
	__webpack_require__.r(__webpack_exports__);

	// EXPORTS
	__webpack_require__.d(__webpack_exports__, {
	  "default": () => (/* binding */ src)
	});

	// EXTERNAL MODULE: external "flatpickr"
	var external_flatpickr_ = __webpack_require__(144);
	var external_flatpickr_default = /*#__PURE__*/__webpack_require__.n(external_flatpickr_);
	// EXTERNAL MODULE: external {"commonjs":"vue","commonjs2":"vue","amd":"vue","root":"Vue"}
	var external_commonjs_vue_commonjs2_vue_amd_vue_root_Vue_ = __webpack_require__(594);
	const includedEvents = [
	    'onChange',
	    'onClose',
	    'onDestroy',
	    'onMonthChange',
	    'onOpen',
	    'onYearChange',
	];
	// Let's not emit these events by default
	const excludedEvents = [
	    'onValueUpdate',
	    'onDayCreate',
	    'onParseConfig',
	    'onReady',
	    'onPreCalendarPosition',
	    'onKeyDown',
	];
	function camelToKebab(string) {
	    return string.replace(/([a-z])([A-Z])/g, '$1-$2').toLowerCase();
	}
	function arrayify(obj) {
	    return obj instanceof Array
	        ? obj
	        : [obj];
	}
	function nullify(value) {
	    return (value && value.length)
	        ? value
	        : null;
	}




	// Keep a copy of all events for later use
	const allEvents = [...includedEvents, ...excludedEvents];
	// Passing these properties in `fp.set()` method will cause flatpickr to trigger some callbacks
	const configCallbacks = ['locale', 'showMonths'];
	/* harmony default export */ const component = ((0, external_commonjs_vue_commonjs2_vue_amd_vue_root_Vue_.defineComponent)({
	    name: 'FlatPickr',
	    compatConfig: {
	        MODE: 3,
	    },
	    render() {
	        return (0, external_commonjs_vue_commonjs2_vue_amd_vue_root_Vue_.h)('input', {
	            type: 'text',
	            'data-input': true,
	            disabled: this.disabled,
	            onInput: this.onInput,
	        });
	    },
	    emits: [
	        'blur',
	        'update:modelValue',
	        ...allEvents.map(camelToKebab)
	    ],
	    props: {
	        modelValue: {
	            type: [String, Number, Date, Array, null],
	            required: true,
	        },
	        // https://flatpickr.js.org/options/
	        config: {
	            type: Object,
	            default: () => ({
	                defaultDate: null,
	                wrap: false,
	            })
	        },
	        events: {
	            type: Array,
	            default: () => includedEvents
	        },
	        disabled: {
	            type: Boolean,
	            default: false
	        },
	    },
	    data() {
	        return {
	            fp: null, //todo make it non-reactive
	        };
	    },
	    mounted() {
	        // Return early if flatpickr is already loaded
	        /* istanbul ignore if */
	        if (this.fp)
	            return;
	        // Init flatpickr
	        this.fp = external_flatpickr_default()(this.getElem(), this.prepareConfig());
	        // Attach blur event
	        this.fpInput().addEventListener('blur', this.onBlur);
	        // Immediate watch will fail before fp is set,
	        // so we need to start watching after mount
	        this.$watch('disabled', this.watchDisabled, {
	            immediate: true
	        });
	    },
	    methods: {
	        prepareConfig() {
	            // Don't mutate original object on parent component
	            let safeConfig = Object.assign({}, this.config);
	            this.events.forEach((hook) => {
	                // Respect global callbacks registered via setDefault() method
	                let globalCallbacks = (external_flatpickr_default()).defaultConfig[hook] || [];
	                // Inject our own method along with user's callbacks
	                let localCallback = (...args) => {
	                    this.$emit(camelToKebab(hook), ...args);
	                };
	                // Overwrite with merged array
	                safeConfig[hook] = arrayify(safeConfig[hook] || []).concat(globalCallbacks, localCallback);
	            });
	            const onCloseCb = this.onClose.bind(this);
	            safeConfig['onClose'] = arrayify(safeConfig['onClose'] || []).concat(onCloseCb);
	            // Set initial date without emitting any event
	            safeConfig.defaultDate = this.modelValue || safeConfig.defaultDate;
	            return safeConfig;
	        },
	        /**
	         * Get the HTML node where flatpickr to be attached
	         * Bind on parent element if wrap is true
	         */
	        getElem() {
	            return this.config.wrap ? this.$el.parentNode : this.$el;
	        },
	        /**
	         * Watch for value changed by date-picker itself and notify parent component
	         */
	        onInput(event) {
	            const input = event.target;
	            // Let's wait for DOM to be updated
	            (0, external_commonjs_vue_commonjs2_vue_amd_vue_root_Vue_.nextTick)().then(() => {
	                this.$emit('update:modelValue', nullify(input.value));
	            });
	        },
	        fpInput() {
	            return this.fp.altInput || this.fp.input;
	        },
	        /**
	         * Blur event is required by many validation libraries
	         */
	        onBlur(event) {
	            this.$emit('blur', nullify(event.target.value));
	        },
	        /**
	         * Flatpickr does not emit input event in some cases
	         */
	        onClose(selectedDates, dateStr) {
	            this.$emit('update:modelValue', dateStr);
	        },
	        /**
	         * Watch for the disabled property and sets the value to the real input.
	         */
	        watchDisabled(newState) {
	            if (newState) {
	                this.fpInput().setAttribute('disabled', '');
	            }
	            else {
	                this.fpInput().removeAttribute('disabled');
	            }
	        }
	    },
	    watch: {
	        /**
	         * Watch for any config changes and redraw date-picker
	         */
	        config: {
	            deep: true,
	            handler(newConfig) {
	                if (!this.fp)
	                    return;
	                let safeConfig = Object.assign({}, newConfig);
	                // Workaround: Don't pass hooks to configs again otherwise
	                // previously registered hooks will stop working
	                // Notice: we are looping through all events
	                // This also means that new callbacks can not be passed once component has been initialized
	                allEvents.forEach((hook) => {
	                    delete safeConfig[hook];
	                });
	                this.fp.set(safeConfig);
	                // Workaround: Allow to change locale dynamically
	                configCallbacks.forEach((name) => {
	                    if (typeof safeConfig[name] !== 'undefined') {
	                        this.fp.set(name, safeConfig[name]);
	                    }
	                });
	            }
	        },
	        /**
	         * Watch for changes from parent component and update DOM
	         */
	        modelValue(newValue) {
	            var _a;
	            // Prevent updates if v-model value is same as input's current value
	            if (!this.$el || newValue === nullify(this.$el.value))
	                return;
	            // Notify flatpickr instance that there is a change in value
	            (_a = this.fp) === null || _a === void 0 ? void 0 : _a.setDate(newValue, true);
	        }
	    },
	    beforeUnmount() {
	        /* istanbul ignore else */
	        if (!this.fp)
	            return;
	        this.fpInput().removeEventListener('blur', this.onBlur);
	        this.fp.destroy();
	        this.fp = null;
	    }
	}));

	/* harmony default export */ const src = (component);

	/******/ 	return __webpack_exports__;
	/******/ })()
	;
	}); 
} (index_umd$1));

var index_umdExports = index_umd$1.exports;
const FlatPickr = /*@__PURE__*/getDefaultExportFromCjs(index_umdExports);

export { FlatPickr as F, __nuxt_component_0 as _ };
//# sourceMappingURL=index.umd.mjs.map
