import{e,n}from"./Dzt7KM-5.js";const s={__name:"index",setup(t){return e(async()=>n("/home")),(a,r)=>null}};export{s as default};
