import{b5 as a,O as e,n as o}from"./BYEtENzq.js";const s=a(()=>{const t=e("token"),r=e("role");if(t.value)return r.value==="supplier"?o("/home"):o("/")});export{s as default};
