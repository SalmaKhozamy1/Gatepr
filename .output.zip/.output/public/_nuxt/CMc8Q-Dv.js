import{bL as o,bd as a,bM as r}from"./CDbRZE7w.js";function b(){r({variableName:a("scrollbar.width").name})}function c(){o({variableName:a("scrollbar.width").name})}export{b,c as u};
