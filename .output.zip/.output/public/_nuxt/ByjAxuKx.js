import{b5 as a,P as e,n as o}from"./DoA-PpbY.js";const s=a(()=>{const t=e("token"),r=e("role");if(t.value)return r.value==="supplier"?o("/home"):o("/")});export{s as default};
