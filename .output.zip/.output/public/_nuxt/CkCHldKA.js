import{aZ as r,O as e,n as o}from"./CDbRZE7w.js";const s=r(()=>{const t=e("token"),a=e("role");if(t.value)return a.value==="supplier"?o("/home"):o("/")});export{s as default};
