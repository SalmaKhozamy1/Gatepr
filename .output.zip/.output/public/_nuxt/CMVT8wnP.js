import{b2 as e,g as o,n as t}from"./B6v3udN6.js";const i=e(()=>{if(!o("token").value)return t("/login/admin")});export{i as default};
