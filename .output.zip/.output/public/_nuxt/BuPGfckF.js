import{_ as o,j as c,o as e,m as n}from"./Dzt7KM-5.js";const t={};function r(s,a){const _=n;return e(),c(_)}const m=o(t,[["render",r]]);export{m as default};
