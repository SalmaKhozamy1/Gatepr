import{aZ as n,O as e,n as o}from"./Dzt7KM-5.js";const u=n(i=>{const t=e("token"),a=e("role");if(!t.value)return o("/login/admin");if(a.value!=="admin")return o("/home")});export{u as default};
