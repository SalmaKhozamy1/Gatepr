import{b2 as e,g as o,n as t}from"./B6v3udN6.js";const s=e(()=>{if(o("token").value)return t("/admin/home")});export{s as default};
