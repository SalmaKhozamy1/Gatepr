import{f as t,u as a,k as o}from"./DoA-PpbY.js";const c=e=>{const{t:s}=t();a({title:o(()=>s(e))})};export{c as u};
