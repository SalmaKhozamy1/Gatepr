import{f as a,h as o,u,l as c}from"./Dzt7KM-5.js";const n=t=>{const{t:e}=a(),s=o();s.meta.title=t,u({title:c(()=>e(t))})};export{n as u};
