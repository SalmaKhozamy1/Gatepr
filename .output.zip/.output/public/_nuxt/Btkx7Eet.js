import{b5 as e,O as o,n as t}from"./BYEtENzq.js";const i=e(()=>{if(!o("token").value)return t("/login/supplier")});export{i as default};
