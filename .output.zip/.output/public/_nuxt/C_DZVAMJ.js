import{e as t,u as a,l as o}from"./BYEtENzq.js";const c=e=>{const{t:s}=t();a({title:o(()=>s(e))})};export{c as u};
