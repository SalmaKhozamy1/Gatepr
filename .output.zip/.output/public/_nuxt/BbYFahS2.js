import{j as a,n as t,c as o,o as s}from"./BYEtENzq.js";const l={__name:"index",setup(n){const e=a();return t(e("/settings/governorates")),(c,r)=>(s(),o("div"))}};export{l as default};
