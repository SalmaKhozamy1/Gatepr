import{bM as o,be as a,bN as r}from"./DoA-PpbY.js";function b(){r({variableName:a("scrollbar.width").name})}function c(){o({variableName:a("scrollbar.width").name})}export{b,c as u};
