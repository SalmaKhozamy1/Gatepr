import{e,n}from"./DoA-PpbY.js";const s={__name:"index",setup(t){return e(async()=>n("/home")),(a,r)=>null}};export{s as default};
