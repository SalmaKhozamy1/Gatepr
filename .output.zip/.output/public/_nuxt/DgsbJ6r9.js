import{b5 as e,P as o,n as t}from"./DoA-PpbY.js";const i=e(()=>{if(!o("token").value)return t("/login/supplier")});export{i as default};
