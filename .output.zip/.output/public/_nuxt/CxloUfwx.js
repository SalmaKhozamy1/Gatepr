import{bJ as o,bb as a,bK as r}from"./B6v3udN6.js";function b(){r({variableName:a("scrollbar.width").name})}function c(){o({variableName:a("scrollbar.width").name})}export{b,c as u};
