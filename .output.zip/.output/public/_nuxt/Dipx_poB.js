import{aY as s,O as u,r as n}from"./Dzt7KM-5.js";const c=s("auth",()=>{const e=n(null),o=u("token");return{user:e,setUser:t=>{e.value=t},logout:()=>{e.value=null,o.value=null}}});export{c as u};
