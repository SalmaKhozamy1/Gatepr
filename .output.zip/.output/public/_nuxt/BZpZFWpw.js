import{f as t,u as a,k as o}from"./CDbRZE7w.js";const c=e=>{const{t:s}=t();a({title:o(()=>s(e))})};export{c as u};
