import{aZ as e,O as o,n as t}from"./CDbRZE7w.js";const i=e(()=>{if(!o("token").value)return t("/login/supplier")});export{i as default};
